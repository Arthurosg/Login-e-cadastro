const query = new URLSearchParams(location.search).get('query');
const searchFilter = e => e.toLocaleLowerCase().includes(query.toLocaleLowerCase());

const appsContainer = document.querySelector('#apps-container');
const noApps = `<h2 class="display-3 text-center">Nenhuma aplicativo encontrado</h2>`
if (query) db.apps = db.apps.filter(app => [app.title, app.content].some(searchFilter));
appsContainer.innerHTML = !db.apps.length ? noApps : db.apps.map(app =>
`<div class="d-flex align-items-strech col-sm-6 col-md-4 my-3">
    <div class="card">
        <img src="${app.image}" class="rounded" class="card-img-top" alt="${app.title}">
        <div class="card-body">
            <h5 class="card-title">${app.title}</h5>
            <p class="card-text">${app.content}</p>
        </div>
        <button type="button" class="btn btn-info">Info</button>
    </div>
</div>`).join('\n');

const newsContainer = document.querySelector('#news-container');
const noNews = `<h2 class="display-3 text-center">Nenhuma notícia encontrada</h2>`
if (query) db.news = db.news.filter(news => [news.title, news.content].some(searchFilter));
newsContainer.innerHTML = !db.news.length ? noNews : db.news.map(news =>
`<div class="card bg-dark text-white text-center mt-1">
    <img height="250" src="${news.image}" class="card-img" alt="${news.title}">
    <div class="card-img-overlay mt-5">
        <h5 class="card-title">${news.title}</h5>
        <p class="card-text">${news.content}</p>
    </div>
</div>`).join('\n');
