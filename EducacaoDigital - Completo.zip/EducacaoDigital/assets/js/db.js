const db = {
    apps: [
        {
            title: "Facebook ipsum dolor sit amet consectetur adipisicing elit.  ipsum dolor sit amet consectetur adipisicing elit",
            image: "/assets/img/tec.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/tec.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/tec.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/tec.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/tec.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/tec.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
    ],
    news: [
        {
            title: "Facebook ipsum dolor sit amet consectetur adipisicing elit.  ipsum dolor sit amet consectetur adipisicing elit",
            image: "/assets/img/banner.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/banner.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/banner.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/banner.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/banner.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
        {
            title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
            image: "/assets/img/banner.jpg",
            content: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        },
    ]
};
